-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Май 23 2016 г., 06:22
-- Версия сервера: 10.0.17-MariaDB
-- Версия PHP: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `accatering`
--

-- --------------------------------------------------------

--
-- Структура таблицы `menu`
--

CREATE TABLE `menu` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `menu`
--

INSERT INTO `menu` (`id`, `type`, `name`) VALUES
(1, 'one', 'Sebzelı Fırın Tavuk'),
(2, 'one', 'Tavuk haslama'),
(3, 'one', 'Tavuk Sarma'),
(5, 'one', 'Tavuk Etkertme'),
(6, 'one', 'Tavuk doloma'),
(7, 'two', 'Et Kavurma'),
(8, 'two', 'Kuzu Haslama'),
(9, 'two', 'Et rosto sebzeli'),
(10, 'two', 'Etli gudes'),
(11, 'three', 'Izmir kofte'),
(12, 'three', 'Hasan Pasa kofte'),
(13, 'three', 'Sebzeli kofte'),
(14, 'three', 'Dalyan kofte'),
(15, 'three', 'Dizi kofte'),
(16, 'four', 'Mercimek corbasy'),
(17, 'four', 'Poca corbasy'),
(18, 'four', 'Yayla corbasy'),
(20, 'four', 'Tavuk corbasy'),
(21, 'four', 'Sebze corbasy'),
(22, 'four', 'Domates corbasy'),
(23, 'five', 'Şeker pare'),
(24, 'five', 'Revani'),
(25, 'five', 'Lokma'),
(26, 'five', 'Islak kek'),
(27, 'five', 'Baklava'),
(28, 'five', 'Koko krem'),
(29, 'five', 'Muhallebi'),
(30, 'five', 'Kekskul'),
(31, 'six', 'Cay'),
(32, 'six', 'Kahve'),
(33, 'six', 'Sut'),
(34, 'six', 'Ayran'),
(35, 'six', 'Asitli icecekler');

-- --------------------------------------------------------

--
-- Структура таблицы `message`
--

CREATE TABLE `message` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `people` int(10) NOT NULL,
  `date` varchar(15) NOT NULL,
  `time` varchar(15) NOT NULL,
  `plan` text NOT NULL,
  `plan1` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `message`
--

INSERT INTO `message` (`id`, `name`, `surname`, `email`, `phone`, `people`, `date`, `time`, `plan`, `plan1`) VALUES
(6, 'Zharas', 'Muzarap', 'jasik090498@gmail.com', '87789105060', 18, '2016-05-20', '14:00', 'Birthday', 'I want to celebrate my Birthday with "maklube"!!!');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(100) UNSIGNED NOT NULL,
  `card` int(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `card`, `password`, `name`, `surname`) VALUES
(1, 150107069, '980409350568', 'ADMIN', 'admin'),
(12, 150107070, '123', 'Daniyar', 'Meyramov'),
(16, 150107020, 'qweqwe', 'Yermurat', 'Taken');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT для таблицы `message`
--
ALTER TABLE `message`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
